No nosso incremento implementamos as interfaces de utiliza��o de cada poss�vel utilizador, isto �, a interface dirigida ao estafeta, a interface dirigida ao cliente e, por fim, a interface dirigida ao restaurante/representante do restaurante.
A app m�vel utiliz�vel com suporte em Android que pode ser encontrada em https://micro-site-ams.herokuapp.com/ clicando em �Try Live� debaixo da sec��o projetos.

Aqui tamb�m pode ser encontrado o c�digo desenvolvido (https://github.com/bearkillerPT/appAMS) e o download da app para ser utilizada em Android clicando no bot�o �Download�.

Depois de estar na app na sec��o username consoante a interface que queremos ver colocamos como username o utilizador, i.e., se quisesse entrar como cliente colocaria o username �cliente� e uma password aleat�ria.
	
Depois de estar logado ainda podemos dar logout clicando no bot�o correspondente.
